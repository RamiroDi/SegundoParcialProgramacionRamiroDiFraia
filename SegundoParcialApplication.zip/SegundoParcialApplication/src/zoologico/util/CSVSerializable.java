package zoologico.util;

public interface CSVSerializable {
    // Convierte el objeto a formato CSV
    String toCSV();

    // Crea un objeto a partir de una cadena CSV
    static CSVSerializable fromCSV(String csv) {
        throw new UnsupportedOperationException("Este método debe ser implementado por la clase.");
    }
}
