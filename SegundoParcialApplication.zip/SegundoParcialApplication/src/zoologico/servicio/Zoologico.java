package zoologico.servicio;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import zoologico.modelo.Animal;
import zoologico.util.CSVSerializable;

public class Zoologico<T extends CSVSerializable & Comparable<T>> {
    private List<T> inventario;

    public Zoologico() {
        this.inventario = new ArrayList<>();
    }

    // Agregar un elemento al inventario
    public void agregar(T elemento) {
        inventario.add(elemento);
    }

    // Obtener un elemento por índice
    public T obtener(int indice) {
        if (indice < 0 || indice >= inventario.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango.");
        }
        return inventario.get(indice);
    }

    // Eliminar un elemento por índice
    public void eliminar(int indice) {
        if (indice < 0 || indice >= inventario.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango.");
        }
        inventario.remove(indice);
    }

    // Filtrar elementos según un criterio
    public List<T> filtrar(Predicate<T> criterio) {
        return inventario.stream()
                         .filter(criterio)
                         .collect(Collectors.toList());
    }

    // Ordenar los elementos de manera natural (por el método compareTo)
    public void ordenar() {
        Collections.sort(inventario);
    }

    // Ordenar los elementos usando un Comparator personalizado
    public void ordenar(Comparator<T> comparator) {
        inventario.sort(comparator);
    }
    
    // En la clase Zoologico
    public void paraCadaElemento(Consumer<T> accion) {
        inventario.forEach(accion);
    }
    
    // Método para guardar en archivo binario
    public void guardarEnArchivo(String path) throws IOException {
        // Crear la carpeta si no existe
        File carpeta = new File("data");
        if (!carpeta.exists()) {
            carpeta.mkdir();
        }

        // Guardar archivo binario
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(inventario);
        }
    }

    // Cargar el inventario desde un archivo binario
    public void cargarDesdeArchivo(String rutaArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(rutaArchivo))) {
            inventario = (List<T>) ois.readObject();
        }
    }

    // Método para guardar en archivo CSV
    public void guardarEnCSV(String path) throws IOException {
        File carpeta = new File("data");
        if (!carpeta.exists()) {
            carpeta.mkdir();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            writer.write("id,nombre,especie,alimentacion\n");  // Escribir el encabezado
            for (T elemento : inventario) {
                Animal a = (Animal) elemento; // Suponiendo que todos los elementos son de tipo Animal
                writer.write(a.getId() + "," + a.getNombre() + "," + a.getEspecie() + "," + a.getAlimentacion() + "\n");
            }
        }
    }


    public void cargarDesdeCSV(String rutaArchivo, Function<String, T> fromCSV) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            inventario.clear(); // Limpiar el inventario antes de cargar los nuevos elementos
            String linea;
            reader.readLine(); // Leer y descartar la primera línea (cabecera)
            while ((linea = reader.readLine()) != null) {
                inventario.add(fromCSV.apply(linea)); // Convertir cada línea a un objeto de tipo T
            }
    }
}

}
