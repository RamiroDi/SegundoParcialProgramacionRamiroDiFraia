package zoologico.modelo;

import zoologico.util.CSVSerializable;
import java.io.Serializable;

public class Animal implements Comparable<Animal>, CSVSerializable, Serializable {
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    // Constructor
    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    public void setAlimentacion(TipoAlimentacion alimentacion) {
        this.alimentacion = alimentacion;
    }

    // Implementación de Comparable para ordenar por id
    @Override
    public int compareTo(Animal otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toString() {
        return "Animal{id=" + id + ", nombre='" + nombre + '\'' +
               ", especie='" + especie + '\'' +
               ", alimentacion=" + alimentacion + '}';
    }

    // Implementación del método toCSV de la interfaz CSVSerializable
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion.name();
    }

    // Método estático para crear un Animal desde una cadena CSV
    public static Animal fromCSV(String csv) {
        try {
            String[] campos = csv.split(",");
            if (campos.length != 4) {
                throw new IllegalArgumentException("CSV mal formado. Se esperaban 4 campos.");
            }
            int id = Integer.parseInt(campos[0]);
            String nombre = campos[1];
            String especie = campos[2];
            TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(campos[3]);
            return new Animal(id, nombre, especie, alimentacion);
        } catch (Exception e) {
            throw new IllegalArgumentException("Error al parsear el CSV: " + e.getMessage(), e);
        }
    }
}
